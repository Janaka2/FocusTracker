# FocusLens

> Honest active-time tracking for Chrome.
> Classify sites, see your real focus score, return to deep work — calmly.

FocusLens measures only the seconds you are **actively** using a tab — visible, focused, and interacting — and shows you where that time really went. Five hours on GitHub is not the same as five hours on TikTok, and FocusLens treats you like an adult who can tell the difference.

* **Local-first.** All data lives in `chrome.storage.local`. Nothing is sent anywhere.
* **No build step.** Plain ES modules, MV3, vanilla SVG charts. Drop the folder into Chrome and run.
* **Coach, not cop.** Calm tone, small encouragements, no shame patterns.

---

## Install (developer mode)

1. Open `chrome://extensions/`
2. Toggle **Developer mode** (top right)
3. Click **Load unpacked**
4. Select this folder
5. Pin the extension to your toolbar

That's it. Open a few sites, then click the icon for the popup, or open the dashboard for the full view.

## What's inside

```
manifest.json
background/
  service-worker.js     # tracker, alarms, blocker, message router
content/
  interaction-tracker.js # reports interactions + visibility
  overlay.js / .css      # soft warning banner for Distraction sites
popup/
  popup.html / .css / .js
dashboard/
  dashboard.html / .css / .js  # focus score, weekly bars, donut, top sites
options/
  options.html / .css / .js    # rules CRUD, settings, import/export
blocked/
  blocked.html / .css / .js    # calm full-page block with friction override
lib/
  constants.js, storage.js, classify.js, score.js,
  format.js, encouragement.js
data/
  defaultRules.json     # ~120 pre-classified sites
icons/
  icon-{16,32,48,128}.png
```

## How tracking works

A second is counted only when **all** of the following are true:

1. The Chrome window is **focused**.
2. The tab is the **active** tab.
3. The page is **visible** (`document.visibilityState === 'visible'`).
4. The user has **interacted within the last 60 s** (configurable).
5. `chrome.idle` reports `active` (catches OS lock & screensaver).

The service worker drives a 5-second tick while alive, plus a 1-minute `chrome.alarms` keepalive when it sleeps. User interactions also trigger opportunistic ticks. Only the eTLD+1 domain is stored — never page content or titles.

## Categories

| Code | Name              | Bucket     |
|------|-------------------|------------|
| A    | Deep Work         | Productive |
| B    | Learning          | Productive |
| C    | Work Tools        | Productive |
| D    | Useful Research   | Productive |
| E    | Communication     | Neutral    |
| F    | Neutral           | Neutral    |
| G    | Distraction       | Wasted     |
| H    | Blocked           | Wasted     |

Edit any rule in **Settings → Rules**. Rule precedence: regex → path → subdomain → domain → default `F`.

## Focus score

```
raw      = 1.0·P + 0.3·N − 0.8·G − 1.5·H
penalty  = 60·blockedHits + 120·overrides
score    = clamp( round( (raw − penalty) / (6h) · 100 ), 0, 100 )
```

A clean 6 hours of pure productive work scores 100. The full formula lives in `lib/score.js` as a pure function.

## Privacy

* No accounts. No analytics. No remote calls.
* Only domain-level data, optionally path-level for fine-grained rules (`youtube.com/shorts`).
* Export any time as JSON. Wipe any time in **Settings → Data**.
* Open-source core; you can audit every file in this repo.

## Roadmap

v0.1 (this MVP) ships the loop: track → classify → score → gently redirect.
Next:
* Goals & streaks
* Weekly review screen
* Path-aware YouTube split out of the box
* Optional end-to-end encrypted sync
* AI auto-classifier and weekly coach (opt-in)

## License

MIT — see `LICENSE` (not yet committed; add one before publishing).
