// FocusLens — MV3 service worker.
// Tracks active browsing time using a 4-gate model:
//   (1) window focused  (2) tab active  (3) page visible  (4) user not idle.
// Aggregates seconds into per-domain sessions and a per-day summary.

import {
  getRules, setRules, getSettings, getState, setState, getDailySummary,
  setDailySummary, emptyDay, getOverrides, setOverrides, getMeta, setMeta,
  appendSession, getSessions, setSessions
} from '../lib/storage.js';
import { classify, getDomain, getHost, isTrackableURL } from '../lib/classify.js';
import { focusScore } from '../lib/score.js';
import { todayKey } from '../lib/format.js';
import { pickForEvent } from '../lib/encouragement.js';

const TICK_ALARM = 'focuslens-tick';
const COMPACT_ALARM = 'focuslens-compact';
const MIDNIGHT_ALARM = 'focuslens-midnight';

// In-memory mirror of the runtime state for speed.
// The SW may be evicted; we re-hydrate from storage on wake.
let mem = null;

// ---------------------------------------------------------------- bootstrap

chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    await firstRunSetup();
  } else if (details.reason === 'update') {
    await ensureDefaults();
  }
  await scheduleAlarms();
  await hydrate();
});

chrome.runtime.onStartup.addListener(async () => {
  await ensureDefaults();
  await scheduleAlarms();
  await hydrate();
});

// Wake on action click → ensure state is fresh.
chrome.action.onClicked.addListener(async () => { await hydrate(); });

async function firstRunSetup() {
  const meta = await getMeta();
  if (!meta.installedAt) await setMeta({ installedAt: Date.now() });
  const defaults = await fetchDefaultRules();
  await setRules(defaults);
}

async function ensureDefaults() {
  const rules = await getRules();
  if (!rules || rules.length === 0) {
    const defaults = await fetchDefaultRules();
    await setRules(defaults);
  }
}

async function fetchDefaultRules() {
  const url = chrome.runtime.getURL('data/defaultRules.json');
  const res = await fetch(url);
  return await res.json();
}

async function scheduleAlarms() {
  // 5-second tick is too short for chrome.alarms (min 30s in many builds),
  // so we drive ticks both via alarms (keepalive every 1 min) and via
  // setInterval that survives as long as the SW is alive.
  chrome.alarms.create(TICK_ALARM, { periodInMinutes: 1 });
  chrome.alarms.create(COMPACT_ALARM, { periodInMinutes: 60 });
  chrome.alarms.create(MIDNIGHT_ALARM, { when: nextMidnightMs(), periodInMinutes: 24 * 60 });
}

function nextMidnightMs() {
  const d = new Date();
  d.setHours(24, 0, 5, 0);
  return d.getTime();
}

// ------------------------------------------------------- runtime state init

async function hydrate() {
  if (mem) return mem;
  const persisted = await getState();
  mem = persisted || {
    activeDomain: null,
    activeCategory: null,
    activeRuleId: null,
    activeUrl: null,
    activeTabId: null,
    sessionStartMs: null,
    sessionActiveSec: 0,
    interactions: 0,
    lastInteractionMs: Date.now(),
    windowFocused: true,
    tabVisible: true,
    idleState: 'active',
    lastTickMs: Date.now()
  };
  // Refresh current tab on wake.
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tab && tab.url) await switchActiveContext(tab.url, tab.id);
  } catch {}
  return mem;
}

async function persistState() {
  if (!mem) return;
  await setState(mem);
}

// ------------------------------------------------------- gate logic & ticks

async function shouldCount(settings) {
  if (!mem || !mem.activeDomain) return false;
  if (!mem.windowFocused) return false;
  if (!mem.tabVisible) return false;
  if (mem.idleState !== 'active') return false;
  if (Date.now() - mem.lastInteractionMs > settings.idleThresholdSec * 1000) return false;
  if (settings.pauseUntil && Date.now() < new Date(settings.pauseUntil).getTime()) return false;
  return true;
}

async function tick() {
  await hydrate();
  const settings = await getSettings();
  const now = Date.now();
  const dt = Math.max(0, Math.min(60, Math.round((now - mem.lastTickMs) / 1000)));
  mem.lastTickMs = now;
  if (dt === 0) return;
  if (!(await shouldCount(settings))) return;
  await incrementCurrentSession(dt);
}

async function incrementCurrentSession(sec) {
  if (!mem.activeDomain) return;
  if (!mem.sessionStartMs) mem.sessionStartMs = Date.now() - sec * 1000;
  mem.sessionActiveSec += sec;

  const dateKey = todayKey();
  const daily = await getDailySummary();
  const day = daily[dateKey] || emptyDay();
  day.totalActiveSec += sec;
  day.byCategory[mem.activeCategory] = (day.byCategory[mem.activeCategory] || 0) + sec;
  day.byDomain[mem.activeDomain] = (day.byDomain[mem.activeDomain] || 0) + sec;
  const hour = new Date().getHours();
  day.byHour[hour] = (day.byHour[hour] || 0) + sec;
  day.focusScore = focusScore(day);
  daily[dateKey] = day;
  await setDailySummary(daily);
  await persistState();
}

// ------------------------------------------------------- session lifecycle

async function switchActiveContext(url, tabId) {
  if (!isTrackableURL(url)) {
    await flushSession('non-trackable');
    return;
  }
  const domain = getDomain(url);
  const host = getHost(url);
  if (!domain) return;

  const rules = await getRules();
  const { category, ruleId } = classify(url, rules);

  if (mem && mem.activeDomain === domain && mem.activeCategory === category) {
    // Same context, just refresh URL/tab.
    mem.activeUrl = url;
    mem.activeTabId = tabId;
    await persistState();
    return;
  }

  await flushSession('switch');
  await hydrate();
  mem.activeDomain = domain;
  mem.activeCategory = category;
  mem.activeRuleId = ruleId;
  mem.activeUrl = url;
  mem.activeTabId = tabId;
  mem.sessionStartMs = Date.now();
  mem.sessionActiveSec = 0;
  mem.interactions = 0;
  mem.lastInteractionMs = Date.now();
  mem.lastTickMs = Date.now();
  await persistState();

  // If we hit a Blocked site, intercept (unless overridden).
  if (category === 'H') {
    await handleBlockedHit(host || domain, url, tabId);
  }
}

async function flushSession(reason) {
  if (!mem || !mem.activeDomain || mem.sessionActiveSec <= 0) {
    if (mem) { mem.activeDomain = null; mem.activeCategory = null; mem.sessionStartMs = null; }
    return;
  }
  const session = {
    id: `s_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    domain: mem.activeDomain,
    category: mem.activeCategory,
    startedAt: mem.sessionStartMs,
    endedAt: Date.now(),
    activeSec: mem.sessionActiveSec,
    interactions: mem.interactions,
    endReason: reason
  };
  await appendSession(session);
  mem.activeDomain = null;
  mem.activeCategory = null;
  mem.activeRuleId = null;
  mem.activeUrl = null;
  mem.sessionStartMs = null;
  mem.sessionActiveSec = 0;
  mem.interactions = 0;
  await persistState();
}

// ------------------------------------------------------------ block handler

async function handleBlockedHit(host, url, tabId) {
  const overrides = await getOverrides();
  const ovr = overrides[host];
  if (ovr && ovr.expiresAt > Date.now()) return; // override still valid

  // Record hit in today's summary.
  const dateKey = todayKey();
  const daily = await getDailySummary();
  const day = daily[dateKey] || emptyDay();
  day.blockedHits = (day.blockedHits || 0) + 1;
  daily[dateKey] = day;
  await setDailySummary(daily);

  // Redirect tab to blocked page.
  const target = chrome.runtime.getURL(
    `blocked/blocked.html?from=${encodeURIComponent(host)}&url=${encodeURIComponent(url)}`
  );
  try { await chrome.tabs.update(tabId, { url: target }); } catch {}
}

// ----------------------------------------------------------------- listeners

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab && tab.url) await switchActiveContext(tab.url, tabId);
  } catch {}
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete' && !changeInfo.url) return;
  if (!tab.active) return;
  if (tab.url) await switchActiveContext(tab.url, tabId);
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  await hydrate();
  if (mem && mem.activeTabId === tabId) await flushSession('tab-closed');
});

chrome.windows.onFocusChanged.addListener(async (winId) => {
  await hydrate();
  const focused = winId !== chrome.windows.WINDOW_ID_NONE;
  mem.windowFocused = focused;
  if (!focused) {
    await flushSession('window-blur');
  } else {
    try {
      const [tab] = await chrome.tabs.query({ active: true, windowId: winId });
      if (tab && tab.url) await switchActiveContext(tab.url, tab.id);
    } catch {}
  }
  await persistState();
});

chrome.idle.setDetectionInterval(60);
chrome.idle.onStateChanged.addListener(async (state) => {
  await hydrate();
  mem.idleState = state;
  if (state !== 'active') await flushSession('idle-' + state);
  await persistState();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === TICK_ALARM) {
    await tick();
  } else if (alarm.name === COMPACT_ALARM) {
    await compactSessions();
  } else if (alarm.name === MIDNIGHT_ALARM) {
    await flushSession('midnight');
  }
});

// Messages from content scripts and UI.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      switch (msg.type) {
        case 'INTERACTION': {
          await hydrate();
          mem.lastInteractionMs = Date.now();
          mem.interactions += 1;
          if (mem.idleState !== 'active') mem.idleState = 'active';
          // Opportunistic tick so seconds accumulate even if alarm hasn't fired.
          await tick();
          sendResponse({ ok: true });
          break;
        }
        case 'VISIBILITY': {
          await hydrate();
          mem.tabVisible = !!msg.visible;
          if (!mem.tabVisible) await flushSession('visibility');
          else if (sender.tab && sender.tab.url) await switchActiveContext(sender.tab.url, sender.tab.id);
          sendResponse({ ok: true });
          break;
        }
        case 'GET_CURRENT_CATEGORY': {
          await hydrate();
          const url = msg.url || (sender.tab && sender.tab.url);
          const rules = await getRules();
          const c = classify(url, rules);
          sendResponse({ ...c, domain: getDomain(url), host: getHost(url) });
          break;
        }
        case 'CLASSIFY_CURRENT': {
          await hydrate();
          const rules = await getRules();
          const r = classify(msg.url, rules);
          sendResponse(r);
          break;
        }
        case 'SET_CATEGORY_FOR_DOMAIN': {
          const rules = await getRules();
          const domain = msg.domain;
          const idx = rules.findIndex((r) => r.type === 'domain' && r.match === domain);
          if (idx >= 0) rules[idx].category = msg.category;
          else rules.unshift({ id: 'u_' + Date.now(), type: 'domain', match: domain, category: msg.category });
          await setRules(rules);
          // Re-classify current context immediately.
          if (mem && mem.activeUrl) await switchActiveContext(mem.activeUrl, mem.activeTabId);
          sendResponse({ ok: true });
          break;
        }
        case 'GRANT_OVERRIDE': {
          const settings = await getSettings();
          const overrides = await getOverrides();
          overrides[msg.host] = {
            expiresAt: Date.now() + settings.overrideMinutes * 60 * 1000,
            reason: msg.reason || ''
          };
          await setOverrides(overrides);
          const daily = await getDailySummary();
          const day = daily[todayKey()] || emptyDay();
          day.overrides = (day.overrides || 0) + 1;
          daily[todayKey()] = day;
          await setDailySummary(daily);
          sendResponse({ ok: true, expiresAt: overrides[msg.host].expiresAt });
          break;
        }
        case 'PAUSE_TRACKING': {
          const settings = await getSettings();
          const minutes = Math.max(1, Math.min(240, msg.minutes || 30));
          const until = new Date(Date.now() + minutes * 60 * 1000).toISOString();
          await chrome.storage.local.set({
            settings: { ...settings, pauseUntil: until }
          });
          await flushSession('pause');
          sendResponse({ ok: true, until });
          break;
        }
        case 'RESUME_TRACKING': {
          const settings = await getSettings();
          await chrome.storage.local.set({ settings: { ...settings, pauseUntil: null } });
          sendResponse({ ok: true });
          break;
        }
        case 'OPEN_DASHBOARD': {
          chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html') });
          sendResponse({ ok: true });
          break;
        }
        case 'NAVIGATE_AWAY': {
          const tabId = sender && sender.tab && sender.tab.id;
          if (tabId != null) {
            try { await chrome.tabs.update(tabId, { url: 'chrome://newtab/' }); }
            catch { try { await chrome.tabs.remove(tabId); } catch {} }
          }
          sendResponse({ ok: true });
          break;
        }
        case 'GET_ENCOURAGEMENT': {
          sendResponse({ text: pickForEvent(msg.event || 'morning') });
          break;
        }
        default:
          sendResponse({ ok: false, error: 'unknown-type' });
      }
    } catch (e) {
      sendResponse({ ok: false, error: String(e && e.message || e) });
    }
  })();
  return true; // async
});

// ------------------------------------------------------------- maintenance

async function compactSessions() {
  const settings = await getSettings();
  const cutoff = Date.now() - settings.retentionDays * 24 * 3600 * 1000;
  const sessions = await getSessions();
  const kept = sessions.filter((s) => s.endedAt >= cutoff);
  if (kept.length !== sessions.length) await setSessions(kept);
  await setMeta({ lastCompactedAt: Date.now() });
}

// Best-effort: a fast in-SW timer so we don't only rely on alarms (which are
// limited to 1-minute resolution). When the SW is alive, ticks happen every
// 5 seconds. When it's evicted, alarms still flush every 60 seconds.
let _fastTickHandle = null;
function startFastTick() {
  if (_fastTickHandle) return;
  _fastTickHandle = setInterval(() => { tick().catch(() => {}); }, 5000);
}
startFastTick();
