import { getDailySummary, getRules } from '../lib/storage.js';
import { bucketTotals, focusScore, classifyScore } from '../lib/score.js';
import { fmtShort, fmtDuration, todayKey, lastNDays, prettyDomain, delta, pct } from '../lib/format.js';
import { CATEGORIES, CATEGORY_ORDER, BUCKETS } from '../lib/constants.js';

const $ = (s) => document.querySelector(s);

let state = { range: 'today' };

function aggregateRange(daily, dateKeys) {
  const total = {
    totalActiveSec: 0,
    byCategory: { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0, G: 0, H: 0 },
    byDomain: {},
    byHour: Array(24).fill(0),
    blockedHits: 0,
    overrides: 0,
    days: []
  };
  for (const k of dateKeys) {
    const d = daily[k];
    if (!d) { total.days.push({ key: k, day: null }); continue; }
    total.totalActiveSec += d.totalActiveSec || 0;
    for (const c of CATEGORY_ORDER) total.byCategory[c] += d.byCategory[c] || 0;
    for (const [dom, sec] of Object.entries(d.byDomain || {})) {
      total.byDomain[dom] = (total.byDomain[dom] || 0) + sec;
    }
    for (let h = 0; h < 24; h++) total.byHour[h] += (d.byHour && d.byHour[h]) || 0;
    total.blockedHits += d.blockedHits || 0;
    total.overrides += d.overrides || 0;
    total.days.push({ key: k, day: d });
  }
  total.focusScore = focusScore(total);
  return total;
}

function setScoreUI(score) {
  $('#score-val').textContent = score;
  const arc = $('#score-arc');
  const C = 2 * Math.PI * 34;
  arc.setAttribute('stroke-dashoffset', String(C - (score / 100) * C));
  arc.classList.remove('s-high', 's-mid', 's-low');
  if (score >= 60) arc.classList.add('s-high');
  else if (score >= 30) arc.classList.add('s-mid');
  else arc.classList.add('s-low');
  $('#score-tag').textContent = classifyScore(score).label;
}

function renderStats(today, yesterday) {
  const tt = bucketTotals(today);
  const yt = bucketTotals(yesterday);
  $('#productive-num').textContent = fmtShort(tt.productive);
  $('#neutral-num').textContent = fmtShort(tt.neutral);
  $('#wasted-num').textContent = fmtShort(tt.wasted);
  setScoreUI(focusScore(today));

  const pd = delta(tt.productive, yt.productive);
  const wd = delta(tt.wasted, yt.wasted);
  $('#productive-delta').innerHTML = renderDelta(pd, true);
  $('#wasted-delta').innerHTML = renderDelta(wd, false);
}

function renderDelta(d, higherIsBetter) {
  if (!d || d.value === 0) return '<span class="muted">vs yesterday: —</span>';
  const arrow = d.value > 0 ? '▲' : '▼';
  const cls = (d.value > 0) === higherIsBetter ? 'delta-up' : 'delta-down';
  return `<span class="${cls}">${arrow} ${fmtShort(Math.abs(d.value))}</span> <span class="muted">vs yesterday</span>`;
}

// Weekly stacked bars (last 7 days).
function renderWeekly(daily) {
  const keys = lastNDays(7);
  const wrap = $('#weekly-chart');
  wrap.innerHTML = '';
  const max = Math.max(1, ...keys.map((k) => (daily[k] && daily[k].totalActiveSec) || 0));
  const todayK = todayKey();
  for (const k of keys) {
    const d = daily[k];
    const b = bucketTotals(d);
    const tot = b.productive + b.neutral + b.wasted;
    const ratio = tot / max;
    const col = document.createElement('div');
    col.className = 'bar-col' + (k === todayK ? ' today' : '');
    const date = new Date(k + 'T00:00:00');
    col.title = `${date.toDateString()} — ${fmtDuration(tot, { compact: true })}`;
    col.innerHTML = `
      <div class="bar-stack" style="height: ${Math.round(180 * ratio) || 1}px;">
        <div class="bar-seg" style="height:${pctOf(b.productive, tot)}%; background:${BUCKETS.productive.color}"></div>
        <div class="bar-seg" style="height:${pctOf(b.neutral, tot)}%; background:${BUCKETS.neutral.color}"></div>
        <div class="bar-seg" style="height:${pctOf(b.wasted, tot)}%; background:${BUCKETS.wasted.color}"></div>
      </div>
      <div class="bar-label">${date.toLocaleDateString(undefined, { weekday: 'short' })}</div>
    `;
    wrap.appendChild(col);
  }
}

function pctOf(part, total) { return total ? Math.round((part / total) * 100) : 0; }

// Donut showing today's category split.
function renderDonut(day) {
  const svg = $('#donut-svg');
  svg.innerHTML = '';
  const legend = $('#donut-legend');
  legend.innerHTML = '';
  const cx = 60, cy = 60, r = 44, sw = 18;
  const cats = CATEGORY_ORDER.map((c) => ({ c, sec: (day && day.byCategory[c]) || 0 }))
    .filter((x) => x.sec > 0);
  const total = cats.reduce((s, x) => s + x.sec, 0);

  // Background ring
  const bg = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
  bg.setAttribute('cx', cx); bg.setAttribute('cy', cy); bg.setAttribute('r', r);
  bg.setAttribute('stroke', '#E2E8F0'); bg.setAttribute('stroke-width', sw); bg.setAttribute('fill', 'none');
  svg.appendChild(bg);

  if (total === 0) {
    const txt = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    txt.setAttribute('x', cx); txt.setAttribute('y', cy + 4);
    txt.setAttribute('text-anchor', 'middle'); txt.setAttribute('fill', '#94A3B8');
    txt.setAttribute('font-size', '12');
    txt.textContent = 'No data yet';
    svg.appendChild(txt);
    legend.innerHTML = '<li class="muted">Start browsing to see your split.</li>';
    return;
  }

  const circ = 2 * Math.PI * r;
  let offset = 0;
  for (const { c, sec } of cats) {
    const frac = sec / total;
    const len = circ * frac;
    const seg = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    seg.setAttribute('cx', cx); seg.setAttribute('cy', cy); seg.setAttribute('r', r);
    seg.setAttribute('fill', 'none');
    seg.setAttribute('stroke', CATEGORIES[c].color);
    seg.setAttribute('stroke-width', sw);
    seg.setAttribute('stroke-dasharray', `${len} ${circ - len}`);
    seg.setAttribute('stroke-dashoffset', String(-offset));
    seg.setAttribute('transform', `rotate(-90 ${cx} ${cy})`);
    svg.appendChild(seg);
    offset += len;

    const li = document.createElement('li');
    li.innerHTML = `
      <span class="swatch" style="background:${CATEGORIES[c].color}"></span>
      <span class="lbl">${CATEGORIES[c].name}</span>
      <span class="val">${fmtShort(sec)}</span>
    `;
    legend.appendChild(li);
  }

  const centerVal = document.createElementNS('http://www.w3.org/2000/svg', 'text');
  centerVal.setAttribute('x', cx); centerVal.setAttribute('y', cy - 2);
  centerVal.setAttribute('text-anchor', 'middle'); centerVal.setAttribute('font-size', '14');
  centerVal.setAttribute('font-weight', '700'); centerVal.setAttribute('fill', '#0f172a');
  centerVal.textContent = fmtShort(total);
  svg.appendChild(centerVal);
  const centerLbl = document.createElementNS('http://www.w3.org/2000/svg', 'text');
  centerLbl.setAttribute('x', cx); centerLbl.setAttribute('y', cy + 14);
  centerLbl.setAttribute('text-anchor', 'middle'); centerLbl.setAttribute('font-size', '10');
  centerLbl.setAttribute('fill', '#64748b');
  centerLbl.textContent = 'active';
  svg.appendChild(centerLbl);
}

function renderTopSites(day, rules) {
  const byDomain = (day && day.byDomain) || {};
  const ruleMap = new Map();
  for (const r of rules) {
    if (r.type === 'domain') ruleMap.set(r.match, r.category);
  }
  const entries = Object.entries(byDomain).map(([dom, sec]) => {
    const cat = ruleMap.get(dom) || 'F';
    return { dom, sec, cat, bucket: CATEGORIES[cat] ? CATEGORIES[cat].bucket : 'neutral' };
  });
  const prod = entries.filter((e) => e.bucket === 'productive').sort((a, b) => b.sec - a.sec).slice(0, 5);
  const wast = entries.filter((e) => e.bucket === 'wasted').sort((a, b) => b.sec - a.sec).slice(0, 5);
  fillRanklist($('#top-productive'), prod, 'productive');
  fillRanklist($('#top-wasted'), wast, 'wasted');
}

function fillRanklist(ol, items, kind) {
  ol.innerHTML = '';
  if (!items.length) {
    ol.innerHTML = `<li class="muted">${kind === 'productive'
      ? 'No productive time yet — pick up where you left off.'
      : 'No distraction time. Quietly impressive.'}</li>`;
    return;
  }
  for (const it of items) {
    const cat = CATEGORIES[it.cat] || CATEGORIES.F;
    const li = document.createElement('li');
    li.innerHTML = `
      <div class="rank-name">
        <span class="rank-dot" style="background:${cat.color}"></span>
        <span class="rank-domain">${prettyDomain(it.dom)}</span>
        <span class="rank-cat">${cat.name}</span>
      </div>
      <div class="rank-val">${fmtShort(it.sec)}</div>
    `;
    ol.appendChild(li);
  }
}

function renderHourChart(day) {
  const wrap = $('#hour-chart');
  wrap.innerHTML = '';
  const hours = (day && day.byHour) || Array(24).fill(0);
  const max = Math.max(60, ...hours);
  for (let h = 0; h < 24; h++) {
    const v = hours[h] || 0;
    const col = document.createElement('div');
    col.className = 'hcol';
    col.style.height = Math.max(1, Math.round((v / max) * 130)) + 'px';
    col.style.background = v > 0 ? '#10B981' : '#E2E8F0';
    col.title = `${String(h).padStart(2, '0')}:00 — ${fmtDuration(v, { compact: true })}`;
    wrap.appendChild(col);
  }
}

function renderSuggestions(today, week) {
  const ul = $('#suggestions');
  ul.innerHTML = '';
  const tt = bucketTotals(today);
  const suggestions = [];

  // Find peak focus hour over the week
  const hourTotals = Array(24).fill(0);
  for (const day of week.days) {
    if (!day.day || !day.day.byHour) continue;
    for (let h = 0; h < 24; h++) hourTotals[h] += day.day.byHour[h];
  }
  const peak = hourTotals.indexOf(Math.max(...hourTotals));
  if (Math.max(...hourTotals) > 60) {
    suggestions.push(`You're most productive around <strong>${peak}:00</strong>. Protect that block.`);
  }

  if (tt.wasted >= 30 * 60) {
    const peakDist = findPeakDistractionHour(today);
    if (peakDist != null) {
      suggestions.push(`Most distraction time landed around <strong>${peakDist}:00</strong>. Try a 5-minute walk before then tomorrow.`);
    } else {
      suggestions.push(`You crossed 30 minutes of distraction today. One small reset can flip the rest of the day.`);
    }
  }

  if (today && today.blockedHits > 0) {
    suggestions.push(`You closed <strong>${today.blockedHits}</strong> blocked site${today.blockedHits === 1 ? '' : 's'} today. That's the whole skill.`);
  }

  if (tt.productive >= 4 * 3600) {
    suggestions.push(`Four hours of real focus. That's a great day — log off when you can.`);
  } else if (tt.productive >= 2 * 3600) {
    suggestions.push(`Two solid hours done. One more pomodoro takes you to three.`);
  } else if (tt.productive < 30 * 60 && tt.wasted > tt.productive) {
    suggestions.push(`Begin small. Open one productive tab and close everything else.`);
  }

  if (!suggestions.length) {
    suggestions.push(`Quiet, even day. Keep going.`);
  }
  for (const s of suggestions) {
    const li = document.createElement('li');
    li.innerHTML = s;
    ul.appendChild(li);
  }
}

function findPeakDistractionHour(day) {
  if (!day) return null;
  // Approximate: we don't track distraction per hour, only total per hour.
  // Heuristic: pick the hour with most total activity if wasted is significant.
  const hours = day.byHour || [];
  let best = -1, bestVal = 0;
  for (let h = 0; h < 24; h++) {
    if ((hours[h] || 0) > bestVal) { bestVal = hours[h]; best = h; }
  }
  return best >= 0 ? best : null;
}

async function render() {
  const daily = await getDailySummary();
  const rules = await getRules();

  let dateKeys = [];
  let title = 'Today';
  let sub = '';
  if (state.range === 'today') {
    dateKeys = [todayKey()];
    title = 'Today';
    sub = new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' });
  } else if (state.range === 'week') {
    dateKeys = lastNDays(7);
    title = 'This week';
    sub = `${dateKeys[0]} → ${dateKeys[dateKeys.length - 1]}`;
  } else {
    dateKeys = lastNDays(30);
    title = 'Last 30 days';
    sub = `${dateKeys[0]} → ${dateKeys[dateKeys.length - 1]}`;
  }
  $('#hero-title').textContent = title;
  $('#hero-sub').textContent = sub;
  $('#weekly-title').textContent = state.range === 'today' ? 'Last 7 days' : (state.range === 'week' ? 'This week' : 'Last 4 weeks');

  const aggregated = aggregateRange(daily, dateKeys);
  const today = daily[todayKey()] || null;
  const yKey = lastNDays(2)[0];
  const yesterday = daily[yKey] || null;

  // Top stat cards always reflect the current range's totals.
  renderStats(state.range === 'today' ? today : aggregated, state.range === 'today' ? yesterday : null);
  renderWeekly(daily);
  renderDonut(state.range === 'today' ? today : aggregated);
  renderTopSites(state.range === 'today' ? today : aggregated, rules);
  renderHourChart(state.range === 'today' ? today : aggregated);
  const weekAgg = aggregateRange(daily, lastNDays(7));
  renderSuggestions(state.range === 'today' ? today : aggregated, weekAgg);
}

document.querySelectorAll('.tab').forEach((t) =>
  t.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((x) => x.classList.remove('active'));
    t.classList.add('active');
    state.range = t.dataset.range;
    render();
  })
);

$('#options-btn').addEventListener('click', () => chrome.runtime.openOptionsPage());

$('#export-btn').addEventListener('click', async () => {
  const data = await new Promise((res) => chrome.storage.local.get(null, (r) => res(r)));
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `focuslens-export-${todayKey()}.json`;
  a.click();
  URL.revokeObjectURL(url);
});

render();
// Auto-refresh every 30s while open.
setInterval(render, 30000);
