import {
  getRules, setRules, getSettings, setSettings, clearAll
} from '../lib/storage.js';
import { CATEGORIES, CATEGORY_ORDER } from '../lib/constants.js';

const $ = (s) => document.querySelector(s);
const $$ = (s) => Array.from(document.querySelectorAll(s));

let state = {
  rules: [],
  filterText: '',
  filterCats: new Set(CATEGORY_ORDER)
};

function send(msg) {
  return new Promise((res) => chrome.runtime.sendMessage(msg, (r) => res(r || {})));
}

async function fetchDefaultRules() {
  const url = chrome.runtime.getURL('data/defaultRules.json');
  const r = await fetch(url);
  return await r.json();
}

// ------------------------- Rules table -------------------------

function renderRules() {
  const body = $('#rules-body');
  body.innerHTML = '';
  const txt = state.filterText.toLowerCase().trim();
  const visible = state.rules.filter((r) =>
    state.filterCats.has(r.category) &&
    (!txt || (r.match || '').toLowerCase().includes(txt))
  );
  if (!visible.length) {
    body.innerHTML = `<tr><td colspan="4" class="muted" style="padding:24px; text-align:center">No rules match.</td></tr>`;
    return;
  }
  for (const r of visible) {
    const tr = document.createElement('tr');
    tr.dataset.id = r.id;
    tr.innerHTML = `
      <td><input type="text" data-field="match" value="${escapeAttr(r.match)}" /></td>
      <td>
        <select data-field="type">
          ${['domain', 'subdomain', 'path', 'regex'].map((t) =>
            `<option value="${t}" ${r.type === t ? 'selected' : ''}>${t}</option>`
          ).join('')}
        </select>
      </td>
      <td>
        <select data-field="category" class="cat-select">
          ${CATEGORY_ORDER.map((c) =>
            `<option value="${c}" ${r.category === c ? 'selected' : ''}>${c} — ${CATEGORIES[c].name}</option>`
          ).join('')}
        </select>
      </td>
      <td style="width:40px; text-align:right;">
        <button class="delete-btn" title="Delete" aria-label="Delete">×</button>
      </td>
    `;
    body.appendChild(tr);
  }
}

function escapeAttr(s) {
  return String(s || '').replace(/"/g, '&quot;').replace(/</g, '&lt;');
}

async function saveRule(id, patch) {
  const i = state.rules.findIndex((r) => r.id === id);
  if (i < 0) return;
  state.rules[i] = { ...state.rules[i], ...patch };
  await setRules(state.rules);
}

async function deleteRuleRow(id) {
  state.rules = state.rules.filter((r) => r.id !== id);
  await setRules(state.rules);
  renderRules();
}

// Inline edit
document.addEventListener('change', async (e) => {
  const tr = e.target.closest('tr[data-id]');
  if (!tr) return;
  const field = e.target.dataset.field;
  if (!field) return;
  await saveRule(tr.dataset.id, { [field]: e.target.value });
});
document.addEventListener('click', async (e) => {
  if (e.target.classList.contains('delete-btn')) {
    const tr = e.target.closest('tr[data-id]');
    if (tr && confirm('Delete this rule?')) await deleteRuleRow(tr.dataset.id);
  }
});

// Search & filters
$('#rule-search').addEventListener('input', (e) => {
  state.filterText = e.target.value;
  renderRules();
});
$$('.filter-cat').forEach((cb) =>
  cb.addEventListener('change', () => {
    state.filterCats = new Set($$('.filter-cat').filter((x) => x.checked).map((x) => x.value));
    renderRules();
  })
);

// Add / dialog
const dlg = $('#rule-dialog');
$('#add-rule').addEventListener('click', () => {
  $('#rule-dialog-title').textContent = 'Add rule';
  $('#r-type').value = 'domain';
  $('#r-match').value = '';
  $('#r-cat').value = 'F';
  dlg.showModal();
});
$('#dlg-cancel').addEventListener('click', () => dlg.close());
$('#rule-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const r = {
    id: 'u_' + Date.now(),
    type: $('#r-type').value,
    match: $('#r-match').value.trim(),
    category: $('#r-cat').value
  };
  if (!r.match) return;
  state.rules.unshift(r);
  await setRules(state.rules);
  dlg.close();
  renderRules();
});

$('#reset-rules').addEventListener('click', async () => {
  if (!confirm('Reset all rules to defaults? Your custom rules will be lost.')) return;
  const defaults = await fetchDefaultRules();
  await setRules(defaults);
  state.rules = defaults;
  renderRules();
});

// ------------------------- Settings -------------------------

const SETTING_FIELDS = [
  'idleThresholdSec', 'dailyGoalProductiveMin', 'dailyBudgetWastedMin', 'retentionDays',
  'blockMode', 'blockDelaySec', 'overrideMinutes'
];
const TOGGLES = ['encouragementEnabled'];

async function loadSettings() {
  const s = await getSettings();
  for (const k of SETTING_FIELDS) {
    const el = document.getElementById(k);
    if (el && s[k] != null) el.value = s[k];
  }
  for (const k of TOGGLES) {
    const el = document.getElementById(k);
    if (el) el.checked = !!s[k];
  }
}

function bindSettings() {
  for (const k of SETTING_FIELDS) {
    const el = document.getElementById(k);
    if (!el) continue;
    el.addEventListener('change', async () => {
      const v = el.type === 'number' ? Number(el.value) : el.value;
      await setSettings({ [k]: v });
    });
  }
  for (const k of TOGGLES) {
    const el = document.getElementById(k);
    if (!el) continue;
    el.addEventListener('change', async () => {
      await setSettings({ [k]: el.checked });
    });
  }
}

// ------------------------- Data -------------------------

$('#export-data').addEventListener('click', async () => {
  const data = await new Promise((res) => chrome.storage.local.get(null, (r) => res(r)));
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `focuslens-backup-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
});

$('#import-data').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    const text = await file.text();
    const data = JSON.parse(text);
    if (!confirm('Importing will overwrite your current data. Continue?')) return;
    await chrome.storage.local.set(data);
    alert('Imported. Reloading…');
    location.reload();
  } catch (err) {
    alert('Could not parse JSON: ' + err.message);
  }
});

$('#wipe-data').addEventListener('click', async () => {
  if (!confirm('This deletes ALL FocusLens data on this device. Continue?')) return;
  if (!confirm('Really? This cannot be undone.')) return;
  await clearAll();
  alert('Wiped. Reloading…');
  location.reload();
});

$('#open-dashboard').addEventListener('click', async () => {
  await send({ type: 'OPEN_DASHBOARD' });
});

// ------------------------- Init -------------------------

async function init() {
  state.rules = await getRules();
  renderRules();
  await loadSettings();
  bindSettings();
}
init();
