import { getDailySummary, getSettings } from '../lib/storage.js';
import { bucketTotals, focusScore, classifyScore } from '../lib/score.js';
import { fmtShort, todayKey, prettyDomain } from '../lib/format.js';
import { CATEGORIES } from '../lib/constants.js';
import { pickFor } from '../lib/encouragement.js';

const $ = (s) => document.querySelector(s);

function send(msg) {
  return new Promise((resolve) => chrome.runtime.sendMessage(msg, (r) => resolve(r || {})));
}

function setScore(score) {
  $('#score-val').textContent = score;
  const circ = 2 * Math.PI * 26; // 163.36
  const offset = circ - (score / 100) * circ;
  const arc = $('#score-arc');
  arc.setAttribute('stroke-dashoffset', String(offset));
  const color = score >= 60 ? '#10B981' : score >= 30 ? '#F59E0B' : '#EF4444';
  arc.setAttribute('stroke', color);
  const cls = classifyScore(score);
  $('#score-label').textContent = 'Focus score';
  $('#score-tag').textContent = cls.label;
}

function bucketOfCategory(cat) {
  return CATEGORIES[cat] ? CATEGORIES[cat].bucket : 'neutral';
}

function setCatPill(cat) {
  const pill = $('#current-cat-pill');
  if (!cat || !CATEGORIES[cat]) {
    pill.textContent = '—';
    pill.className = 'cat-pill';
    return;
  }
  const meta = CATEGORIES[cat];
  pill.textContent = `${cat} · ${meta.name}`;
  pill.className = 'cat-pill cat-' + (cat === 'H' ? 'blocked' : meta.bucket);
}

async function render() {
  const daily = await getDailySummary();
  const day = daily[todayKey()] || null;

  // Header today label
  const opts = { weekday: 'long', month: 'short', day: 'numeric' };
  $('#today-label').textContent = new Date().toLocaleDateString(undefined, opts);

  const totals = bucketTotals(day);
  $('#productive-num').textContent = fmtShort(totals.productive);
  $('#neutral-num').textContent = fmtShort(totals.neutral);
  $('#wasted-num').textContent = fmtShort(totals.wasted);

  setScore(focusScore(day));

  // Current site
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const url = tab && tab.url;
  if (url) {
    const ctx = await send({ type: 'GET_CURRENT_CATEGORY', url });
    $('#current-domain').textContent = ctx && ctx.domain ? prettyDomain(ctx.domain) : (url || '—');
    setCatPill(ctx && ctx.category);
    $('#cat-select').dataset.domain = ctx && ctx.domain ? ctx.domain : '';
    $('#cat-select').value = '';
  } else {
    $('#current-domain').textContent = '—';
    setCatPill(null);
  }

  // Encouragement
  $('#encouragement').textContent = pickFor(day);

  // Pause state
  const settings = await getSettings();
  if (settings.pauseUntil && new Date(settings.pauseUntil).getTime() > Date.now()) {
    $('#pause-btn').textContent = 'Resume tracking';
    $('#pause-btn').dataset.mode = 'resume';
  } else {
    $('#pause-btn').textContent = 'Pause 30 min';
    $('#pause-btn').dataset.mode = 'pause';
  }
}

$('#open-dashboard').addEventListener('click', async () => {
  await send({ type: 'OPEN_DASHBOARD' });
  window.close();
});

$('#options-btn').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});

$('#pause-btn').addEventListener('click', async () => {
  const mode = $('#pause-btn').dataset.mode;
  if (mode === 'resume') await send({ type: 'RESUME_TRACKING' });
  else await send({ type: 'PAUSE_TRACKING', minutes: 30 });
  await render();
});

$('#cat-select').addEventListener('change', async (e) => {
  const value = e.target.value;
  const domain = e.target.dataset.domain;
  if (!value || !domain) return;
  await send({ type: 'SET_CATEGORY_FOR_DOMAIN', domain, category: value });
  await render();
});

render();
