import { getDailySummary, getRules } from '../lib/storage.js';
import { bucketTotals, focusScore } from '../lib/score.js';
import { fmtShort, todayKey, prettyDomain } from '../lib/format.js';
import { CATEGORIES } from '../lib/constants.js';
import { pickForEvent } from '../lib/encouragement.js';

const $ = (s) => document.querySelector(s);
const params = new URLSearchParams(location.search);
const fromHost = params.get('from') || '';
const fromUrl = params.get('url') || '';

function send(msg) {
  return new Promise((res) => chrome.runtime.sendMessage(msg, (r) => res(r || {})));
}

async function render() {
  $('#from-host').textContent = prettyDomain(fromHost) || 'unknown';
  $('#quiet').textContent = pickForEvent('closedBlocked');

  const daily = await getDailySummary();
  const today = daily[todayKey()] || null;
  const t = bucketTotals(today);
  const score = focusScore(today);
  $('#today-summary').textContent = `Focus ${score} · ${fmtShort(t.productive)} productive`;

  // Top 3 productive sites from last 7 days
  const rules = await getRules();
  const ruleMap = new Map();
  for (const r of rules) if (r.type === 'domain') ruleMap.set(r.match, r.category);
  const dayKeys = Object.keys(daily).sort().slice(-7);
  const agg = {};
  for (const k of dayKeys) for (const [d, s] of Object.entries(daily[k].byDomain || {})) agg[d] = (agg[d] || 0) + s;
  const top = Object.entries(agg)
    .map(([d, s]) => ({ d, s, cat: ruleMap.get(d) || 'F' }))
    .filter((x) => ['A', 'B', 'C', 'D'].includes(x.cat))
    .sort((a, b) => b.s - a.s)
    .slice(0, 3);

  const ul = $('#top-productive');
  if (!top.length) {
    ul.innerHTML = `<li class="meta-time">No productive sites yet — try opening a tool you trust.</li>`;
    return;
  }
  for (const t of top) {
    const li = document.createElement('li');
    const cat = CATEGORIES[t.cat] || CATEGORIES.F;
    li.innerHTML = `
      <a href="https://${t.d}" target="_top">
        <span>${prettyDomain(t.d)} <span class="meta-time">· ${cat.name}</span></span>
        <span class="meta-time">${fmtShort(t.s)} this week</span>
      </a>
    `;
    ul.appendChild(li);
  }
}

$('#go-back').addEventListener('click', async () => {
  await send({ type: 'NAVIGATE_AWAY' });
});

// Override flow
const dlg = $('#override-dialog');
const cdEl = $('#countdown');
const goBtn = $('#ovr-go');
const reason = $('#reason');
let cdTimer = null;

$('#override').addEventListener('click', () => {
  reason.value = '';
  cdEl.textContent = '10';
  goBtn.disabled = true;
  dlg.showModal();
  let t = 10;
  if (cdTimer) clearInterval(cdTimer);
  cdTimer = setInterval(() => {
    t -= 1;
    cdEl.textContent = String(Math.max(0, t));
    if (t <= 0) {
      clearInterval(cdTimer); cdTimer = null;
      validate();
    }
  }, 1000);
  reason.addEventListener('input', validate);
});

function validate() {
  const ready = (reason.value || '').trim().length >= 20 && Number(cdEl.textContent) === 0;
  goBtn.disabled = !ready;
}

$('#ovr-cancel').addEventListener('click', () => {
  if (cdTimer) { clearInterval(cdTimer); cdTimer = null; }
  dlg.close();
});

$('#override-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (goBtn.disabled) return;
  await send({ type: 'GRANT_OVERRIDE', host: fromHost, reason: reason.value.trim() });
  // Navigate the tab to the original URL.
  if (fromUrl) location.replace(fromUrl);
  else location.replace(`https://${fromHost}`);
});

render();
