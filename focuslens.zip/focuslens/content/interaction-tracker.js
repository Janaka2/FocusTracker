// Reports user interaction + visibility to the service worker.
// Stays small: only fires at most once per second.

(function () {
  if (window.__focuslens_interaction_installed) return;
  window.__focuslens_interaction_installed = true;

  let last = 0;
  const THROTTLE_MS = 1000;

  function ping() {
    const now = Date.now();
    if (now - last < THROTTLE_MS) return;
    last = now;
    try {
      chrome.runtime.sendMessage({ type: 'INTERACTION', ts: now }, () => void chrome.runtime.lastError);
    } catch {}
  }

  const events = ['mousemove', 'mousedown', 'keydown', 'scroll', 'wheel', 'touchstart', 'click'];
  events.forEach((e) =>
    window.addEventListener(e, ping, { passive: true, capture: true })
  );

  function reportVisibility() {
    try {
      chrome.runtime.sendMessage({
        type: 'VISIBILITY',
        visible: document.visibilityState === 'visible'
      }, () => void chrome.runtime.lastError);
    } catch {}
  }
  document.addEventListener('visibilitychange', reportVisibility, true);
  window.addEventListener('focus', reportVisibility, true);
  window.addEventListener('blur', reportVisibility, true);
  window.addEventListener('pageshow', reportVisibility, true);
  reportVisibility();
})();
