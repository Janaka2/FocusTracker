// Shows a calm warning banner on Distraction (G) sites. One-time per tab load,
// auto-dismisses after 8s. Blocked (H) sites are intercepted by the SW directly.

(function () {
  if (window.__focuslens_overlay_installed) return;
  window.__focuslens_overlay_installed = true;

  // Don't run inside our own pages.
  if (location.protocol === 'chrome-extension:') return;

  function ask() {
    try {
      chrome.runtime.sendMessage(
        { type: 'GET_CURRENT_CATEGORY', url: location.href },
        (res) => {
          if (chrome.runtime.lastError) return;
          if (!res || !res.category) return;
          if (res.category === 'G') showBanner(res);
        }
      );
    } catch {}
  }

  function showBanner(ctx) {
    if (document.getElementById('focuslens-banner')) return;
    const el = document.createElement('div');
    el.id = 'focuslens-banner';
    el.innerHTML = `
      <button class="fl-close" aria-label="Close">×</button>
      <div class="fl-row">
        <span class="fl-dot"></span>
        <span class="fl-title">You marked this site as a distraction</span>
      </div>
      <div class="fl-body">
        Set a small intention — what brought you here?
      </div>
      <div class="fl-actions">
        <button class="fl-stay">Stay 5 min</button>
        <button class="fl-primary fl-back">Take me back</button>
      </div>
    `;
    document.documentElement.appendChild(el);
    requestAnimationFrame(() => el.classList.add('fl-show'));

    const close = () => {
      el.classList.remove('fl-show');
      setTimeout(() => el.remove(), 250);
    };
    el.querySelector('.fl-close').addEventListener('click', close);
    el.querySelector('.fl-stay').addEventListener('click', close);
    el.querySelector('.fl-back').addEventListener('click', () => {
      close();
      try { history.length > 1 ? history.back() : window.close(); } catch { window.close(); }
    });
    setTimeout(() => { if (document.body.contains(el)) close(); }, 12000);
  }

  // Defer slightly so we don't compete with page paint.
  setTimeout(ask, 600);
})();
